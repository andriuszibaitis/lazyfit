import SportsPage from "../page";

export default function ProgramsPage() {
  return <SportsPage />;
}
