import SportsPage from "../page";

export default function WorkoutsPage() {
  return <SportsPage />;
}
