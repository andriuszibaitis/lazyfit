import SportsPage from "../page";

export default function ExercisesPage() {
  return <SportsPage />;
}
